export interface Curso {
  codigo: string;
  nome: string;
  turno?: string;
}

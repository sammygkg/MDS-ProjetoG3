

export interface PeriodoLetivo {
  ano: number;
  periodo: number;
}

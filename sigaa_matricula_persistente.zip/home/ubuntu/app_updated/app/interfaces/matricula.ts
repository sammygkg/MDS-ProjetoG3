export interface Matricula {
  codigo: string;
  nome: string;
  status: 'PreMatricula' | 'Confirmada' | 'Recusada';
  vagasOfertadas: number;
  vagasOcupadas: number;
  horario: Horario;
  vagasDisponiveis?: number;
}

export interface Horario {
  dia: string;
  horaInicio: string;
  horaFim: string;
}



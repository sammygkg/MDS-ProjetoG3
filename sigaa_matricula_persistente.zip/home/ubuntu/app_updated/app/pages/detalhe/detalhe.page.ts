import { Component, OnInit } from '@angular/core';
import { Matricula, Horario } from '../../interfaces/matricula';
import { Aluno } from '../../interfaces/aluno';
import { MatriculaDataService } from '../../providers/matricula-data';

@Component({
  selector: 'app-detalhe',
  templateUrl: './detalhe.page.html',
  styleUrls: ['./detalhe.page.scss'],
})
export class DetalhePage implements OnInit {
  matricula: Matricula;
  aluno: Aluno;

  constructor(private matriculaDataService: MatriculaDataService) { }

  ngOnInit() {
    this.aluno = { nome: 'Pedro', matricula: '12345' }; // Adicionado matricula para Aluno

    // Dados mocados da matrícula
    const matriculaMocada: Matricula = {
      codigo: 'ENE0454',
      nome: 'INTRODUÇÃO À ENGENHARIA DE REDES DE COMUNICAÇÃO',
      status: 'PreMatricula', // Será sobrescrito pelo status salvo
      vagasOfertadas: 60,
      vagasOcupadas: 58,
      horario: { dia: 'Quarta', horaInicio: '08:00', horaFim: '10:00' }
    };

    // Obter status salvo do localStorage usando o serviço
    const savedStatus = this.matriculaDataService.getMatriculaStatus(
      matriculaMocada.codigo,
      this.aluno.matricula
    );

    this.matricula = { ...matriculaMocada, status: savedStatus };

    this.matricula.vagasDisponiveis = this.matricula.vagasOfertadas - this.matricula.vagasOcupadas;
  }

  confirmarMatricula() {
    this.matricula.status = 'Confirmada';
    this.matriculaDataService.setMatriculaStatus(
      this.matricula.codigo,
      this.aluno.matricula,
      'Confirmada'
    );
  }

  cancelarMatricula() {
    this.matricula.status = 'Recusada';
    this.matriculaDataService.setMatriculaStatus(
      this.matricula.codigo,
      this.aluno.matricula,
      'Recusada'
    );
  }
}



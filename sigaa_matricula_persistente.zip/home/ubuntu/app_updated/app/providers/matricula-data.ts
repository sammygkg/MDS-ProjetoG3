import { Injectable } from '@angular/core';
import { Matricula } from '../interfaces/matricula';

@Injectable({
  providedIn: 'root'
})
export class MatriculaDataService {

  constructor() { }

  private getStorageKey(matriculaCodigo: string, alunoMatricula: string): string {
    return `statusMatricula_${matriculaCodigo}_${alunoMatricula}`;
  }

  getMatriculaStatus(matriculaCodigo: string, alunoMatricula: string): 'PreMatricula' | 'Confirmada' | 'Recusada' {
    const key = this.getStorageKey(matriculaCodigo, alunoMatricula);
    const savedStatus = localStorage.getItem(key);
    return (savedStatus || 'PreMatricula') as 'PreMatricula' | 'Confirmada' | 'Recusada';
  }

  setMatriculaStatus(matriculaCodigo: string, alunoMatricula: string, status: 'Confirmada' | 'Recusada'): void {
    const key = this.getStorageKey(matriculaCodigo, alunoMatricula);
    localStorage.setItem(key, status);
  }
}


